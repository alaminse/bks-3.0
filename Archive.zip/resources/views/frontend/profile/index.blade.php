@extends('layouts.app')
@section('title') My Profile @endsection

@section('content')

@include('includes.header', ['pageTitle' => 'My Profile'])

{{-- Profile Header Card --}}
<div class="row mb-6">
    <div class="col-12">
        <div class="card shadow border-0">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <div class="position-relative">
                            <img src="{{ $user->avatar_url }}"
                                 alt="Avatar"
                                 class="rounded-circle border border-3 border-white shadow"
                                 style="width: 120px; height: 120px; object-fit: cover;"
                                 id="avatarPreview">

                            <label for="avatarInput"
                                   class="position-absolute bottom-0 end-0 btn btn-sm btn-primary rounded-circle"
                                   style="width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-camera"></i>
                            </label>

                            <form action="{{ route('profile.upload.avatar') }}"
                                  method="POST"
                                  enctype="multipart/form-data"
                                  id="avatarForm">
                                @csrf
                                <input type="file"
                                       name="avatar"
                                       id="avatarInput"
                                       accept="image/*"
                                       style="display: none;">
                            </form>
                        </div>
                    </div>

                    <div class="col">
                        <h3 class="mb-1">
                            {{ $user->full_name }}
                            @if($user->email_verified_at)
                                <span class="badge bg-success">
                                    <i class="bi bi-check-circle"></i> Verified
                                </span>
                            @endif
                        </h3>
                        <p class="text-muted mb-1">
                            <i class="bi bi-envelope me-2"></i>{{ $user->email }}
                        </p>
                        <p class="text-muted mb-0">
                            <i class="bi bi-calendar me-2"></i>Member since {{ $user->created_at->format('d M Y') }}
                        </p>
                    </div>

                    <div class="col-auto">
                        <div class="text-center p-3 bg-light rounded">
                            <h4 class="text-primary mb-0">${{ number_format($totalEarnings, 2) }}</h4>
                            <small class="text-muted">Wallet Balance</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Statistics Cards --}}
<div class="row g-3 g-sm-6 mb-4 mb-sm-6 stats-row">
    @php
        $cards = [
            ['title'=>'Total Referrals','value'=>$user->total_referrals,'icon'=>'people','color'=>'primary'],
            ['title'=>'Active Referrals','value'=>$user->getActiveReferralsCount(),'icon'=>'check-circle','color'=>'success'],
            ['title'=>'Referrals Earnings','value'=>'$ '.number_format($user->total_referral_earnings,2),'icon'=>'cash-coin','color'=>'success'],
            ['title'=>'Age','value'=>$user->age ?? 'N/A','icon'=>'calendar-event','color'=>'info'],
        ];
    @endphp

    @foreach($cards as $card)
        <div class="col-6 col-sm-6 col-xl-3">
            <div class="card shadow border-0 h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <span class="h6 text-muted d-block mb-2">{{ $card['title'] }}</span>
                            <span class="h3 font-bold">{{ $card['value'] }}</span>
                        </div>
                        <div class="col-auto">
                            <div class="icon icon-shape bg-{{ $card['color'] }} text-white rounded-circle">
                                <i class="bi bi-{{ $card['icon'] }}"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
</div>

<div class="row">
    {{-- Left Column --}}
    <div class="col-lg-4">
        {{-- Social Links Card --}}
        <div class="card shadow border-0 mb-6">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-share me-2"></i>Social Links</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('profile.update.social') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-facebook text-primary"></i> Facebook
                        </label>
                        <input type="url"
                               name="facebook_url"
                               class="form-control"
                               value="{{ $user->profile->facebook_url ?? '' }}"
                               placeholder="https://facebook.com/...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-twitter text-info"></i> Twitter
                        </label>
                        <input type="url"
                               name="twitter_url"
                               class="form-control"
                               value="{{ $user->profile->twitter_url ?? '' }}"
                               placeholder="https://twitter.com/...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-instagram text-danger"></i> Instagram
                        </label>
                        <input type="url"
                               name="instagram_url"
                               class="form-control"
                               value="{{ $user->profile->instagram_url ?? '' }}"
                               placeholder="https://instagram.com/...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-linkedin text-primary"></i> LinkedIn
                        </label>
                        <input type="url"
                               name="linkedin_url"
                               class="form-control"
                               value="{{ $user->profile->linkedin_url ?? '' }}"
                               placeholder="https://linkedin.com/in/...">
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-check-lg me-2"></i>Save Social Links
                    </button>
                </form>
            </div>
        </div>
    </div>

    {{-- Right Column --}}
    <div class="col-lg-8">
        {{-- Basic Information Card --}}
        <div class="card shadow border-0 mb-6">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-person me-2"></i>Basic Information</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('profile.update.basic') }}" method="POST">
                    @csrf

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">First Name *</label>
                            <input type="text"
                                   name="name"
                                   class="form-control @error('name') is-invalid @enderror"
                                   value="{{ old('name', $user->name) }}"
                                   required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text"
                                   name="last_name"
                                   class="form-control @error('last_name') is-invalid @enderror"
                                   value="{{ old('last_name', $user->last_name) }}">
                            @error('last_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email *</label>
                            <input type="email"
                                   name="email"
                                   class="form-control @error('email') is-invalid @enderror"
                                   value="{{ old('email', $user->email) }}"
                                   required>
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date"
                                   name="date_of_birth"
                                   class="form-control @error('date_of_birth') is-invalid @enderror"
                                   value="{{ old('date_of_birth', $user->date_of_birth?->format('Y-m-d')) }}">
                            @error('date_of_birth')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select @error('gender') is-invalid @enderror">
                                <option value="">Select Gender</option>
                                <option value="male" {{ old('gender', $user->gender) == 'male' ? 'selected' : '' }}>Male</option>
                                <option value="female" {{ old('gender', $user->gender) == 'female' ? 'selected' : '' }}>Female</option>
                                <option value="other" {{ old('gender', $user->gender) == 'other' ? 'selected' : '' }}>Other</option>
                            </select>
                            @error('gender')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-2"></i>Update Basic Info
                    </button>
                </form>
            </div>
        </div>

        {{-- Contact Information Card --}}
        <div class="card shadow border-0 mb-6">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-telephone me-2"></i>Contact Information</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('profile.update.details') }}" method="POST">
                    @csrf

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="tel"
                                   name="phone"
                                   class="form-control"
                                   value="{{ old('phone', $user->profile->phone ?? '') }}">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Country</label>
                            <input type="text"
                                   name="country"
                                   class="form-control"
                                   value="{{ old('country', $user->profile->country ?? '') }}">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">State/Division</label>
                            <input type="text"
                                   name="state"
                                   class="form-control"
                                   value="{{ old('state', $user->profile->state ?? '') }}">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">City</label>
                            <input type="text"
                                   name="city"
                                   class="form-control"
                                   value="{{ old('city', $user->profile->city ?? '') }}">
                        </div>

                        <div class="col-md-8 mb-3">
                            <label class="form-label">Address</label>
                            <input type="text"
                                   name="address"
                                   class="form-control"
                                   value="{{ old('address', $user->profile->address ?? '') }}">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Postal Code</label>
                            <input type="text"
                                   name="postal_code"
                                   class="form-control"
                                   value="{{ old('postal_code', $user->profile->postal_code ?? '') }}">
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label">Occupation</label>
                            <input type="text"
                                   name="occupation"
                                   class="form-control"
                                   value="{{ old('occupation', $user->profile->occupation ?? '') }}">
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label">Bio</label>
                            <textarea name="bio"
                                      class="form-control"
                                      rows="3"
                                      placeholder="Tell us about yourself...">{{ old('bio', $user->profile->bio ?? '') }}</textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-2"></i>Update Contact Info
                    </button>
                </form>
            </div>
        </div>

        {{-- Change Password Card --}}
        <div class="card shadow border-0 mb-6">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-shield-lock me-2"></i>Change Password</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('profile.change.password') }}" method="POST">
                    @csrf

                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password"
                                   name="current_password"
                                   class="form-control @error('current_password') is-invalid @enderror"
                                   required>
                            @error('current_password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password"
                                   name="new_password"
                                   class="form-control @error('new_password') is-invalid @enderror"
                                   required>
                            @error('new_password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password"
                                   name="new_password_confirmation"
                                   class="form-control"
                                   required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-key me-2"></i>Change Password
                    </button>
                </form>
            </div>
        </div>

        {{-- Danger Zone Card --}}
        <div class="card shadow border-0 border-danger">
            <div class="card-header bg-danger bg-opacity-10">
                <h5 class="mb-0 text-danger">
                    <i class="bi bi-exclamation-triangle me-2"></i>Danger Zone
                </h5>
            </div>
            <div class="card-body">
                <h6 class="text-danger mb-2">Delete Account</h6>
                <p class="text-muted mb-3">
                    Once you delete your account, there is no going back. Please be certain.
                </p>

                <button type="button"
                        class="btn btn-danger"
                        data-bs-toggle="modal"
                        data-bs-target="#deleteAccountModal">
                    <i class="bi bi-trash me-2"></i>Delete My Account
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Delete Account Modal --}}
<div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="{{ route('profile.delete') }}" method="POST" id="deleteAccountForm">
                @csrf
                @method('DELETE')

                <div class="modal-header border-0">
                    <h5 class="modal-title text-danger">
                        <i class="bi bi-exclamation-triangle me-2"></i>Delete Account
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-circle me-2"></i>
                        <strong>Warning:</strong> This action is permanent and cannot be undone!
                    </div>

                    <p class="mb-3">Please enter your password to confirm account deletion:</p>

                    <div class="mb-3">
                        <label class="form-label">Password *</label>
                        <input type="password"
                               name="password"
                               class="form-control"
                               placeholder="Enter your password"
                               required>
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input"
                               type="checkbox"
                               id="confirmDelete"
                               required>
                        <label class="form-check-label" for="confirmDelete">
                            I understand this action cannot be reversed
                        </label>
                    </div>
                </div>

                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-lg me-2"></i>Cancel
                    </button>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash me-2"></i>Delete Account Permanently
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
// Avatar upload with confirmation and auto-submit
document.getElementById('avatarInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        confirmAction({
            title: 'Upload new avatar?',
            text: 'Your profile picture will be updated',
            icon: 'question',
            confirmButtonText: 'Upload',
            onConfirm: () => {
                // Preview image
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatarPreview').src = e.target.result;
                }
                reader.readAsDataURL(file);

                // Submit form
                document.getElementById('avatarForm').submit();
            },
            onCancel: () => {
                // Reset file input
                e.target.value = '';
            }
        });
    }
});

// Delete account form submission with confirmation
document.getElementById('deleteAccountForm')?.addEventListener('submit', function(e) {
    e.preventDefault();

    const password = this.querySelector('input[name="password"]').value;

    if (!password) {
        Swal.fire({
            icon: 'error',
            title: 'Password Required',
            text: 'Please enter your password to confirm deletion'
        });
        return;
    }

    confirmAction({
        title: 'Are you absolutely sure?',
        text: 'This will permanently delete your account and all associated data!',
        icon: 'warning',
        confirmButtonText: 'Yes, delete permanently!',
        confirmButtonColor: '#dc3545',
        onConfirm: () => {
            this.submit();
        }
    });
});
</script>
@endpush

@push('styles')
<style>
.icon-shape {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.card {
    transition: transform 0.2s, box-shadow 0.2s;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
}

.form-control:focus,
.form-select:focus {
    border-color: var(--bs-primary);
    box-shadow: 0 0 0 0.25rem rgba(var(--bs-primary-rgb), 0.25);
}
</style>
@endpush
