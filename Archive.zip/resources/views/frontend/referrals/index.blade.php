@extends('layouts.app')
@section('title') Referral Dashboard @endsection

@section('content')

@include('includes.header', ['pageTitle' => 'My Referral Dashboard'])

    {{-- Referral Link Card --}}
    <div class="row mb-6">
        <div class="col-12">
            <div class="card shadow border-0">
                <div class="card-body">
                    <h5 class="mb-3">
                        <i class="bi bi-link-45deg me-2"></i>Your Referral Link
                    </h5>

                    <div class="input-group">
                        <input type="text" id="referralLink" class="form-control"
                               value="{{ $user->getReferralLink() }}" readonly>
                        <button class="btn btn-primary"
                            onclick="confirmAction({
                                title: 'Copy referral link?',
                                text: 'This link will be copied to clipboard',
                                icon: 'question',
                                confirmButtonText: 'Copy',
                                onConfirm: () => {
                                    copyLink();
                                    Swal.fire({
                                        toast: true,
                                        position: 'top-end',
                                        icon: 'success',
                                        title: 'Link copied',
                                        showConfirmButton: false,
                                        timer: 1500
                                    });
                                }
                            })">
                            <i class="bi bi-clipboard"></i>
                        </button>
                    </div>

                    <small class="text-muted d-block mt-2">
                        Earn <strong>10%</strong> commission for every successful referral
                    </small>
                </div>
            </div>
        </div>
    </div>

    {{-- Statistics Cards (Wallet Style) --}}
    <div class="row g-3 g-sm-6 mb-4 mb-sm-6 stats-row">
        @php
            $cards = [
                ['title'=>'Total Referrals','value'=>$stats['total_referrals'],'icon'=>'people','color'=>'primary'],
                ['title'=>'Active Referrals','value'=>$stats['active_referrals'],'icon'=>'check-circle','color'=>'success'],
                ['title'=>'Pending Referrals','value'=>$stats['pending_referrals'],'icon'=>'clock','color'=>'warning'],
                ['title'=>'Total Earnings','value'=>'$ '.number_format($stats['total_earnings'],2),'icon'=>'cash-coin','color'=>'success'],
            ];
        @endphp

        @foreach($cards as $card)
            <div class="col-6 col-sm-6 col-xl-4">
                <div class="card shadow border-0 h-100">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <span class="h6 text-muted d-block mb-2">{{ $card['title'] }}</span>
                                <span class="h3 font-bold">{{ $card['value'] }}</span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-{{ $card['color'] }} text-white rounded-circle">
                                    <i class="bi bi-{{ $card['icon'] }}"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach

    </div>

    {{-- Referral List --}}
    <div class="card shadow border-0 mb-6">
        <div class="card-header">
            <h5 class="mb-0"><i class="bi bi-people me-2"></i>My Referrals</h5>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-nowrap">
                <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Activated</th>
                    <th>Earnings</th>
                </tr>
                </thead>
                <tbody>
                @forelse($referrals as $referral)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $referral->referred->name }}</td>
                        <td>{{ $referral->referred->email }}</td>
                        <td>
                            <span class="badge {{ $referral->status === 'active' ? 'bg-success' : 'bg-warning' }}">
                                {{ ucfirst($referral->status) }}
                            </span>
                        </td>
                        <td>
                            {{ $referral->activated_at?->format('d M Y') ?? '—' }}
                        </td>
                        <td class="text-success fw-bold">
                            ${{ number_format($referral->earnings->sum('amount'),2) }}
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            No referrals yet
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        {{ $referrals->links('pagination::bootstrap-5') }}
    </div>

    {{-- Commission History --}}
    <div class="card shadow border-0">
        <div class="card-header">
            <h5 class="mb-0"><i class="bi bi-cash-stack me-2"></i>Commission History</h5>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-nowrap">
                <thead>
                <tr>
                    <th>Date</th>
                    <th>From</th>
                    <th>Rate</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                @forelse($earnings as $earning)
                    <tr>
                        <td>{{ $earning->created_at->format('d M Y') }}</td>
                        <td>{{ $earning->referral->referred->name }}</td>
                        <td>{{ number_format($earning->commission_rate,2) }}%</td>
                        <td class="text-success fw-bold">
                            ${{ number_format($earning->amount,2) }}
                        </td>
                        <td>
                            <span class="badge bg-{{ $earning->status === 'paid' ? 'success' : ($earning->status === 'pending' ? 'warning' : 'danger') }}">
                                {{ ucfirst($earning->status) }}
                            </span>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            No commissions yet
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        {{ $earnings->links('pagination::bootstrap-5') }}
    </div>

@endsection

@push('scripts')
<script>
function copyLink() {
    const input = document.getElementById('referralLink');
    input.select();
    input.setSelectionRange(0, 99999);
    navigator.clipboard?.writeText(input.value) || document.execCommand('copy');
}
</script>
@endpush
